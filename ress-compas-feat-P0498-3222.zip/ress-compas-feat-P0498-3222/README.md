# ress-compas

Ressource d'exemples synchrone REST exposée API pour la solution Easy Services. 

## Developpement

Exécuter le serveur en dev en ligne de commandes depuis la racine du projet :
```
java -Dspring.config.additional-location=$PWD/config-local/ -Dspring.profiles.active=dev,db-zada0 -jar target/ress-compas-1.0.0-SNAPSHOT.jar
```
ou en maven :
```
mvn clean compile spring-boot:run -Dspring-boot.run.profiles=dev,db-zada0 -DadditionalClasspathElements=$PWD/config-local/
```