# Configuration Dev en local

Pour lancer l'application en local, il **faut** :

- indiquer le répertoire dans lequel trouver ces configurations :
  - `-Dspring.config.additional-location=config-local/`

- et charger la configuration d'un ou plusieurs profiles :
  - `-Dspring.profiles.active=dev`
  - `-Dspring.profiles.active=vmoa`
  - `-Dspring.profiles.active=dev,db-zada0`

## Sur IntelliJ

- Menu `Run`
- `Edit Configurations`
- Dans le popup, Section `Build and Run`
  - `Modify options` (Alt+M)
  - `Add VM Options` (Alt+V)

Puis ajouter les options `-D` pour la JVM ci-dessus dans le nouveau champ.

![intellij-configuration-run-local.png](intellij-configuration-run-local.png)

### Profiles

## Profile `dev` / `vmoa`

Profile contenant les details pour l'authentification apkee en DEV ou VMOA

## Profile `db-zada0`

Profile contenant les details de connexion à la base de développement ZADA0

## Profile `sqldebug`

Profile permettant d'afficher les requêtes SQL dans les logs de l'application
