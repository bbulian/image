package fr.ca.cats.p0498.s0764.compas.domain.models;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

public class TypeDeComposantTest {

    @ParameterizedTest
    @MethodSource("provideDataForFindTypeDeComposant")
    void testFindTypeDeComposant(String nomDuComposant, TypeDeComposant expected) {
        assertEquals(
                expected,
                TypeDeComposant.find(nomDuComposant),
                "Mauvais type pour " + nomDuComposant);
    }

    private static Stream<Arguments> provideDataForFindTypeDeComposant() {
        return Stream.of(
                Arguments.of("cms_", TypeDeComposant.CMS),
                Arguments.of("AEM6_PUCC", TypeDeComposant.CMS),
                Arguments.of("CMS_JDK11_AEM6", TypeDeComposant.CMS),
                Arguments.of("CQ5AEM6CMS", TypeDeComposant.INCONNU),
                Arguments.of("deploiement_helm", TypeDeComposant.INFRASTRUCTURE_AS_CODE_CLOUD_NATIF),
                Arguments.of("deploiement_k8s", TypeDeComposant.INFRASTRUCTURE_AS_CODE_CLOUD_NATIF),
                Arguments.of("deploiement_azertyuiop_k8s", TypeDeComposant.INFRASTRUCTURE_AS_CODE_CLOUD_NATIF),
                Arguments.of("hexaboot_sxxxxxx_cd", TypeDeComposant.INFRASTRUCTURE_AS_CODE_CLOUD_NATIF),

                Arguments.of("hexaboot_TEST_cd", TypeDeComposant.INFRASTRUCTURE_AS_CODE_CLOUD_NATIF),
                Arguments.of("deploiement_TEST_k8s", TypeDeComposant.INFRASTRUCTURE_AS_CODE_CLOUD_NATIF),
                Arguments.of("deploiement_k8s", TypeDeComposant.INFRASTRUCTURE_AS_CODE_CLOUD_NATIF),
                Arguments.of("deploiement_helm", TypeDeComposant.INFRASTRUCTURE_AS_CODE_CLOUD_NATIF),
                Arguments.of("publication_ansible_vars", TypeDeComposant.PUBLICATION_ANSIBLE),
                Arguments.of("helm_TEST", TypeDeComposant.CHART_HELM),
                Arguments.of("zbms_TEST", TypeDeComposant.ZBMS),
                Arguments.of("zcopy_TEST", TypeDeComposant.ZCOPY),
                Arguments.of("zcobol_TEST", TypeDeComposant.ZCOBOL),
                Arguments.of("kbna_TEST", TypeDeComposant.KIBANA),
                Arguments.of("elsc_TEST", TypeDeComposant.ELASTICSEARCH),
                Arguments.of("lgst_TEST", TypeDeComposant.LOGSTASH),
                Arguments.of("win_TEST", TypeDeComposant.WINDOWS),
                Arguments.of("unix_TEST", TypeDeComposant.UNIX),
                Arguments.of("pom_TEST", TypeDeComposant.POM),
                Arguments.of("fwk_TEST", TypeDeComposant.FRAMEWORK),
                Arguments.of("lib_TEST", TypeDeComposant.LIBRAIRIE),
                Arguments.of("TEST_bff", TypeDeComposant.BACK_FOR_FRONT),
                Arguments.of("TEST-bff", TypeDeComposant.BACK_FOR_FRONT),
                Arguments.of("bffTEST", TypeDeComposant.BACK_FOR_FRONT),
                Arguments.of("TEST_fe", TypeDeComposant.FRONTEND),
                Arguments.of("TEST-fe", TypeDeComposant.FRONTEND),
                Arguments.of("feTEST", TypeDeComposant.FRONTEND),
                Arguments.of("soas_TEST", TypeDeComposant.SOCLE_ASIC),
                Arguments.of("was_properties_TEST", TypeDeComposant.WAS_PROPERTIES),
                Arguments.of("webapp_TEST", TypeDeComposant.WEBAPP),
                Arguments.of("bdoc_TEST", TypeDeComposant.BDOC),
                Arguments.of("ds_TEST", TypeDeComposant.DATASTAGE),
                Arguments.of("search_TEST", TypeDeComposant.SINEQUA),
                Arguments.of("mdd_TEST", TypeDeComposant.MODELE_DE_DONNEES),
                Arguments.of("cs_TEST", TypeDeComposant.COMPOSANT_SOCLE),
                Arguments.of("em_TEST", TypeDeComposant.EXTENSION_METIER),
                Arguments.of("ua_TEST", TypeDeComposant.UNITE_APPLICATIVE),
                Arguments.of("ua_legacy_TEST", TypeDeComposant.UNITE_APPLICATIVE_HEXABOOT),
                Arguments.of("TEST-hexaboot-back", TypeDeComposant.SERVICE_HEXABOOT),
                Arguments.of("docapi_TEST", TypeDeComposant.DOCUMENTATION_API),
                Arguments.of("apim_TEST", TypeDeComposant.APIM),
                Arguments.of("dmon_TEST", TypeDeComposant.DEMON_EASYSERVICES),
                Arguments.of("metr_TEST", TypeDeComposant.RESSOURCE_METIER),
                Arguments.of("ressTEST", TypeDeComposant.RESSOURCE_EASYSERVICES),
                Arguments.of("ressvx_TEST", TypeDeComposant.RESSOURCE_VIRTUELLE_X),
                Arguments.of("ressv_TEST", TypeDeComposant.RESSOURCE_VIRTUELLE),
                Arguments.of("ress_TEST", TypeDeComposant.RESSOURCE_MODALITE_3),
                Arguments.of("med_TEST", TypeDeComposant.MEDIATION),
                Arguments.of("dao_TEST", TypeDeComposant.DAO),
                Arguments.of("srvf_TEST", TypeDeComposant.SERVICE_FONCTIONNEL),
                Arguments.of("srvx_TEST", TypeDeComposant.SERVICE_B2B),
                Arguments.of("srva_TEST", TypeDeComposant.SERVICE_ADSU),
                Arguments.of("md_TEST", TypeDeComposant.SERVICE_EVT),
                Arguments.of("srvp_TEST", TypeDeComposant.SERVICE_EXTERNE),
                Arguments.of("srvu_TEST", TypeDeComposant.SERVICE_UTILITAIRE),
                Arguments.of("srve_TEST", TypeDeComposant.SERVICE_ENTITE),
                Arguments.of("srvt_TEST", TypeDeComposant.SERVICE_TACHE),
                Arguments.of("cgev_TEST", TypeDeComposant.CONFIGURATION_GEV),
                Arguments.of("gev_tf_TEST", TypeDeComposant.GEV_TRANSFORMATION_JAVA),
                Arguments.of("gev_is_TEST", TypeDeComposant.GEV_IS),
                Arguments.of("bpm_TEST", TypeDeComposant.PROCESSUS_BPM),
                Arguments.of("stack_TEST", TypeDeComposant.STACK_DOCKER),
                Arguments.of("im_TEST", TypeDeComposant.IMAGE_DOCKER),
                Arguments.of("im_app_TEST_ua", TypeDeComposant.IMAGE_DOCKER_UA),
                Arguments.of("im_app_TEST_srv", TypeDeComposant.IMAGE_DOCKER_SERVICE_SOA),
                Arguments.of("cobmf_TEST", TypeDeComposant.COBOL_MICROFOCUS),
                Arguments.of("webliv_TEST", TypeDeComposant.WEBLIV),
                Arguments.of("boreal_TEST", TypeDeComposant.BOREAL_METIER),
                Arguments.of("boreal_presentation_TEST", TypeDeComposant.BOREAL_PRESENTATION),
                Arguments.of("aem6_TEST", TypeDeComposant.CMS),
                Arguments.of("cq5_TEST", TypeDeComposant.CMS),
                Arguments.of("cms_TEST", TypeDeComposant.CMS),

                Arguments.of("ress_fe01_new", TypeDeComposant.RESSOURCE_MODALITE_3),
                Arguments.of("ressfe01_new", TypeDeComposant.RESSOURCE_EASYSERVICES),
                Arguments.of("BOREAL_PresentatiXn", TypeDeComposant.BOREAL_METIER),
                Arguments.of("BOREAL_Presentation_CARMIN", TypeDeComposant.BOREAL_PRESENTATION),
                Arguments.of("CQ5_PUCC", TypeDeComposant.CMS),
                Arguments.of("AEM6_PUCC", TypeDeComposant.CMS),
                Arguments.of("CMS_JDK11_AEM6.5", TypeDeComposant.CMS),
                Arguments.of("CQ5AEM6CMS.5", TypeDeComposant.INCONNU),
                Arguments.of(null, TypeDeComposant.INCONNU)

                
                );
    }

    @ParameterizedTest
    @MethodSource("provideDataForGetLibelleTypeDeComposant")
    void testGetLibelleTypeDeComposant(String nomDuComposant, String expected) {
        assertEquals(
                expected,
                TypeDeComposant.find(nomDuComposant).getLibelle(),
                "Mauvais type pour " + nomDuComposant);
    }

    private static Stream<Arguments> provideDataForGetLibelleTypeDeComposant() {
        return Stream.of(
                Arguments.of("cms_", "CMS"),
                Arguments.of("CQ5AEM6CMS", "Inconnu"),
                Arguments.of("boreal_presentation_toto", "Boréal présentation"),
                Arguments.of("deploiement_helm", "IaC Cloud natif"));
    }

    void logAllType() {
       Arrays.asList(TypeDeComposant.values()).forEach(type -> System.out.println(type + ": " + type.getLibelle()));
    }
}
