package fr.ca.cats.p0498.s0764.compas.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;

import fr.ca.cats.p0498.s0764.compas.exception.CompasException;
import fr.ca.cats.p0498.s0764.compas.service.ArtifactDependenciesService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import fr.ca.cats.p0498.s0764.compas.controller.dto.Artifact;

@ExtendWith(MockitoExtension.class)
class ArtifactDependenciesServiceTest {

    @Mock
    private fr.ca.cats.p0498.s0764.compas.repositories.ArtifactRepository artifactRepository;

    @InjectMocks
    private ArtifactDependenciesService artifactDependenciesService;

    private String checksumArtefact;

    @BeforeEach
    void setUp() {
        checksumArtefact = "test-checksum";
    }

    @Test
    void testGetArtifact_OK() throws CompasException {
        fr.ca.cats.p0498.s0764.compas.repositories.domain.view.Artifact artifactView = mock(fr.ca.cats.p0498.s0764.compas.repositories.domain.view.Artifact.class);

        when(artifactRepository.getArtifactByChecksum(checksumArtefact)).thenReturn(artifactView);
        
        artifactDependenciesService.getArtifact(checksumArtefact);

        verify(artifactRepository, times(1)).getArtifactByChecksum(checksumArtefact);
    }

    @Test
    void testGetArtifact_KO() {
        when(artifactRepository.getArtifactByChecksum(checksumArtefact)).thenThrow(new RuntimeException("Database error"));

        try {
            artifactDependenciesService.getArtifact(checksumArtefact);
            fail("Expected CompasInternalErrorException");
        } catch (CompasException e) {
            assertEquals(500, e.getHttpCode());
        }
    }

    @Test
    void testGetArtifactDependencies_OK() throws CompasException {

        fr.ca.cats.p0498.s0764.compas.repositories.domain.view.Artifact artifactView = mock(fr.ca.cats.p0498.s0764.compas.repositories.domain.view.Artifact.class);
        when(artifactRepository.getArtifactDependenciesByChecksum(checksumArtefact))
            .thenReturn(List.of(artifactView));

        List<Artifact> result = artifactDependenciesService.getArtifactDependencies(checksumArtefact);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertInstanceOf(Artifact.class, result.getFirst());

        verify(artifactRepository, times(1)).getArtifactDependenciesByChecksum(checksumArtefact);
    }

    @Test
    void testGetArtifactDependencies_KO() {
        when(artifactRepository.getArtifactDependenciesByChecksum(checksumArtefact))
            .thenThrow(new RuntimeException("Database error"));

        try {
            artifactDependenciesService.getArtifactDependencies(checksumArtefact);
            fail("Expected CompasInternalErrorException");
        } catch (CompasException e) {
            assertEquals(500, e.getHttpCode());
        }
    }
}
