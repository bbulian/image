package fr.ca.cats.p0498.s0764.compas.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import fr.ca.cats.p0498.s0764.compas.repositories.domain.RunningApp;
import fr.ca.cats.p0498.s0764.compas.repositories.domain.view.ProduitSolution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import fr.ca.cats.p0498.s0764.compas.repositories.EnvRepository;
import fr.ca.cats.p0498.s0764.compas.repositories.RunningAppRepository;
import fr.ca.cats.p0498.s0764.compas.repositories.domain.Env;
import fr.ca.cats.p0498.s0764.compas.service.EnvironnementService;
import fr.ca.cats.p0498.s0764.compas.controller.dto.Environnement;
import static fr.ca.cats.p0498.s0764.compas.repositories.domain.RunningApp.InstalledFrom.K8S;

@ExtendWith(MockitoExtension.class)
class EnvironnementServiceTest {

    @Mock
    private EnvRepository envRepository;

    @Mock
    private RunningAppRepository runningAppRepository;

    @InjectMocks
    private EnvironnementService environnementService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void testGetEmptyListOfEnv() {
        when(envRepository.getEnvToDisplay()).thenReturn(new ArrayList<>());

        List<Environnement> result = environnementService.getKubernetesEnvironnements();

        assertEquals(new ArrayList<>(), result);
        verify(envRepository, times(1)).getEnvToDisplay();
    }

    // strictness = Strictness.LENIENT pour ne pas avoir d'erreur sur le test d'entrée de 
    // runningAppRepository.findEnvList()
    @MockitoSettings(strictness = Strictness.LENIENT)
    @Test
    void testGetListOfEnv() {
        // Setup environnement
        Env env1 = new Env();
        env1.setAfficher(true);
        env1.setName("One more time");
        env1.setCreatedAt(OffsetDateTime.of(2025, 1, 6, 13, 52, 17, 666, ZoneOffset.UTC));

        Env env2 = new Env();
        env2.setAfficher(false);
        env2.setName("Goldorak");
        env2.setCreatedAt(OffsetDateTime.of(2025, 1, 6, 13, 55, 52, 666, ZoneOffset.UTC));        

        List<Env> environnements = new ArrayList<>();
        environnements.add(env1);
        environnements.add(env2);

        List<String> inputOfFindEnvList = new ArrayList<>();
        inputOfFindEnvList.add("One more time");
        inputOfFindEnvList.add("Goldorak");

        List<Environnement> returnListOfFindEnvList = new ArrayList<>();
        returnListOfFindEnvList.add(new Environnement("One more time", 1));
        returnListOfFindEnvList.add(new Environnement("Goldorak", 0));

        when(envRepository.getEnvToDisplay()).thenReturn(environnements);
        when(runningAppRepository.getRunnngAppCountByEnv(inputOfFindEnvList)).thenReturn(returnListOfFindEnvList);
        
        // Run
        List<Environnement> result = environnementService.getKubernetesEnvironnements();

        // Test
        assertEquals(2, result.size());

        List<Environnement> one_result = result.stream()
            .filter(p -> p.name().equals(env1.getName())).collect(Collectors.toList());

        assertEquals(env1.getName(), one_result.getFirst().name());
        assertEquals(1, one_result.getFirst().runningApp().size());

        one_result = result.stream()
            .filter(p -> p.name().equals(env2.getName())).toList();

        assertEquals(env2.getName(), one_result.getFirst().name());
        assertEquals(0, one_result.getFirst().runningApp().size());

        verify(envRepository, times(1)).getEnvToDisplay();
    }

    List<RunningApp> createRunningApp(String produit, String solution) {
        var solution1_1 = new RunningApp();
        solution1_1.setCodeProduit(produit);
        solution1_1.setCodeSolution(solution);

        var solution1_2 = new RunningApp();
        solution1_2.setCodeProduit(produit);
        solution1_2.setCodeSolution(solution);

        List<RunningApp> listRunningApps = new ArrayList<>();
        listRunningApps.add(solution1_1);
        listRunningApps.add(solution1_2);

        return listRunningApps;
    }

    // strictness = Strictness.LENIENT pour ne pas avoir d'erreur sur le test d'entrée de
    // runningAppRepository.findEnvList()
    @MockitoSettings(strictness = Strictness.LENIENT)
    @Test
    void testGetListOfDeploiementsProduitSolutionEnvironnement() {
        List<ProduitSolution> listOfProduitSolution = new ArrayList<>();
        listOfProduitSolution.add(new ProduitSolution("p0001", "s0001"));
        listOfProduitSolution.add(new ProduitSolution("p0002", "s0002"));

        var listRunningAppsForP0001AndS0001 = createRunningApp("p0001", "p0001");
        var listRunningAppsForP0002AndS0002 = createRunningApp("p0002", "p0002");

        when(runningAppRepository.getProduitSolutionByEnvAndEnvType("d1", K8S)).thenReturn(listOfProduitSolution);
        when(runningAppRepository.getRunningApps("d1", K8S, "p0001", "s0001")).thenReturn(listRunningAppsForP0001AndS0001);
        when(runningAppRepository.getRunningApps("d1", K8S, "p0002", "s0002")).thenReturn(listRunningAppsForP0002AndS0002);

        //environnementService.getRunningAppsByEnvType("d1", K8S);

        verify(runningAppRepository, times(1)).getProduitSolutionByEnvAndEnvType("d1", K8S);
        verify(runningAppRepository, times(1)).getRunningApps("d1", K8S, "p0001", "s0001");
        verify(runningAppRepository, times(1)).getRunningApps("d1", K8S, "p0002", "s0002");
    }
}
