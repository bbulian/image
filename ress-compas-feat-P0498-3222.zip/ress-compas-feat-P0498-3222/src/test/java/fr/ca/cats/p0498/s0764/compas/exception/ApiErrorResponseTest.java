package fr.ca.cats.p0498.s0764.compas.exception;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ApiErrorResponseTest {
            
    @Test
    void testArtifactNotFound() {
        try {
            throw CompasException.artifactNotFound();
        } catch (CompasException e) {
            Assertions.assertEquals(404, e.getHttpCode());
        }
    }

    @Test
    void testDatabaseServerError() {
        try {
            throw CompasException.databaseServerError("toto");
        } catch (CompasException e) {
            Assertions.assertEquals(500, e.getHttpCode());
        }
    }
}
