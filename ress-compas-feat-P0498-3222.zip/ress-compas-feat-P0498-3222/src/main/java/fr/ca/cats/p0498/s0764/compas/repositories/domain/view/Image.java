package fr.ca.cats.p0498.s0764.compas.repositories.domain.view;

public interface Image {
    String getImageName();
    String getImageVersion();
    String getImageChecksum();
    String getImageProduit();
    String getImageSolution();
    String getImageRepoUrl();
    String getImageRepoCommit();
    String getImageRepoRef();
    String getImageRepoTag();
}
