package fr.ca.cats.p0498.s0764.compas.controller.dto;

import org.apache.commons.lang3.StringUtils;

public record Environnement(String name, RunningAppSize runningApp) {
	public Environnement(String name, long runningAppNumber) {
		this(StringUtils.isNotBlank(name) ? name : "", new RunningAppSize(runningAppNumber));
	}

}
