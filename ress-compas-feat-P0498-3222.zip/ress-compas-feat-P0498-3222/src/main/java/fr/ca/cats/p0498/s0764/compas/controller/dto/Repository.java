package fr.ca.cats.p0498.s0764.compas.controller.dto;

public record Repository(String url) { }
