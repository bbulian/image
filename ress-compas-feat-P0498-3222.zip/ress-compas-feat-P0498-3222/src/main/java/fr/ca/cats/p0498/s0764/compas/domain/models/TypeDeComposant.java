package fr.ca.cats.p0498.s0764.compas.domain.models;

import java.util.Arrays;
import java.util.function.Predicate;

import fr.ca.cats.p0498.s0764.compas.utils.StringUtils;

public enum TypeDeComposant {

    CMS(
            "CMS",
            nom -> StringUtils.startsWithAny(nom, "cms_", "cq5_", "aem6_")),
    BOREAL_PRESENTATION(
            "Boréal présentation",
            nom -> StringUtils.startsWithAny(nom, "boreal_presentation_")),
    BOREAL_METIER(
            "Boréal métier",
            nom -> StringUtils.startsWithAny(nom, "boreal_")),
    WEBLIV(
            "Webliv",
            nom -> StringUtils.startsWithAny(nom, "webliv_")),
    COBOL_MICROFOCUS(
            "Cobol Microfocus",
            nom -> StringUtils.startsWithAny(nom, "cobmf_")),
    IMAGE_DOCKER_SERVICE_SOA("Image docker service SOA",
            nom -> StringUtils.startsWithAndContainsAny(nom, "im_app_", "_srv")),
    IMAGE_DOCKER_UA(
            "Image docker UA",
            nom -> StringUtils.startsWithAndContainsAny(nom, "im_app_", "_ua")),
    IMAGE_DOCKER(
            "Image docker",
            nom -> StringUtils.startsWithAny(nom, "im_")),
    STACK_DOCKER(
            "stack_",
            nom -> StringUtils.startsWithAny(nom, "stack_")),
    PROCESSUS_BPM(
            "Processus BPM",
            nom -> StringUtils.startsWithAny(nom, "bpm_")),
    GEV_IS(
            "GEV_IS",
            nom -> StringUtils.startsWithAny(nom, "gev_is_")),
    GEV_TRANSFORMATION_JAVA(
            "GEV Transformation Java",
            nom -> StringUtils.startsWithAny(nom, "gev_tf_")),
    CONFIGURATION_GEV(
            "Configuration GEV",
            nom -> StringUtils.startsWithAny(nom, "cgev_")),
    SERVICE_TACHE(
            "Service tâche",
            nom -> StringUtils.startsWithAny(nom, "srvt_")),
    SERVICE_ENTITE(
            "Service entité",
            nom -> StringUtils.startsWithAny(nom, "srve_")),
    SERVICE_UTILITAIRE(
            "Service utilitaire",
            nom -> StringUtils.startsWithAny(nom, "srvu_")),
    SERVICE_EXTERNE(
            "Service externe",
            nom -> StringUtils.startsWithAny(nom, "srvp_")),
    SERVICE_EVT(
            "MD",
            nom -> StringUtils.startsWithAny(nom, "md_")),
    SERVICE_ADSU(
            "Service ADSU",
            nom -> StringUtils.startsWithAny(nom, "srva_")),
    SERVICE_B2B(
            "Service B2B",
            nom -> StringUtils.startsWithAny(nom, "srvx_")),
    SERVICE_FONCTIONNEL(
            "SRVF (Exposition de SF)",
            nom -> StringUtils.startsWithAny(nom, "srvf_")),
    DAO(
            "DAO",
            nom -> StringUtils.startsWithAny(nom, "dao_")),
    MEDIATION(
            "Mediation",
            nom -> StringUtils.startsWithAny(nom, "med_")),
    RESSOURCE_MODALITE_3(
            "Ressource modalité 3",
            nom -> StringUtils.startsWithAny(nom, "ress_")),
    RESSOURCE_VIRTUELLE(
            "Ressource virtuelle",
            nom -> StringUtils.startsWithAny(nom, "ressv_")),
    RESSOURCE_VIRTUELLE_X(
            "Ressource virtuelle X",
            nom -> StringUtils.startsWithAny(nom, "ressvx_")),
    RESSOURCE_EASYSERVICES(
            "Ressource Easy Services",
            nom -> StringUtils.startsWithAny(nom, "ress")),
    RESSOURCE_METIER(
            "Ressource métier",
            nom -> StringUtils.startsWithAny(nom, "metr")),
    DEMON_EASYSERVICES(
            "Démon Easy Services",
            nom -> StringUtils.startsWithAny(nom, "dmon")),
    APIM(
            "Exposition API (APIM)",
            nom -> StringUtils.startsWithAny(nom, "apim_")),
    DOCUMENTATION_API(
            "Documentation API",
            nom -> StringUtils.startsWithAny(nom, "docapi_")),
    SERVICE_HEXABOOT(
            "Service Hexaboot",
            nom -> StringUtils.endsWithAny(nom, "-hexaboot-back")),
    UNITE_APPLICATIVE_HEXABOOT(
            "Unité Applicative Hexaboot",
            nom -> StringUtils.startsWithAny(nom, "ua_legacy_")),
    UNITE_APPLICATIVE(
            "Unité Applicative",
            nom -> StringUtils.startsWithAny(nom, "ua_")),
    EXTENSION_METIER(
            "Extension métier",
            nom -> StringUtils.startsWithAny(nom, "em_")),
    COMPOSANT_SOCLE(
            "Composant socle",
            nom -> StringUtils.startsWithAny(nom, "cs_")),
    MODELE_DE_DONNEES(
            "Modèle de données",
            nom -> StringUtils.startsWithAny(nom, "mdd_")),
    SINEQUA(
            "Sinequa",
            nom -> StringUtils.startsWithAny(nom, "search_")),
    DATASTAGE(
            "DataStage",
            nom -> StringUtils.startsWithAny(nom, "ds_")),
    BDOC(
            "Modèle BDOC",
            nom -> StringUtils.startsWithAny(nom, "bdoc_")),
    WEBAPP(
            "WebApp_",
            nom -> StringUtils.startsWithAny(nom, "webapp_")),
    WAS_PROPERTIES(
            "WAS_Properties",
            nom -> StringUtils.startsWithAny(nom, "was_properties_")),
    SOCLE_ASIC(
            "Socle ASIC",
            nom -> StringUtils.startsWithAny(nom, "soas_")),
    FRONTEND(
            "Front end",
            nom -> StringUtils.startsWithOrContainsAny(nom, "fe", "-fe", "_fe")),
    BACK_FOR_FRONT(
            "Back for front",
            nom -> StringUtils.startsWithOrContainsAny(nom, "bff", "-bff", "_bff")),
    LIBRAIRIE(
            "Librairie",
            nom -> StringUtils.startsWithAny(nom, "lib_")),
    FRAMEWORK(
            "Framework",
            nom -> StringUtils.startsWithAny(nom, "fwk_")),
    POM(
            "POM Maven",
            nom -> StringUtils.startsWithAny(nom, "pom_")),
    UNIX(
            "Unix",
            nom -> StringUtils.startsWithAny(nom, "unix_")),
    WINDOWS(
            "Windows",
            nom -> StringUtils.startsWithAny(nom, "win_")),
    LOGSTASH(
            "LogStash",
            nom -> StringUtils.startsWithAny(nom, "lgst_")),
    ELASTICSEARCH(
            "Elasticsearch",
            nom -> StringUtils.startsWithAny(nom, "elsc_")),
    KIBANA(
            "Kibana",
            nom -> StringUtils.startsWithAny(nom, "kbna_")),
    ZCOBOL(
            "Zcobol_",
            nom -> StringUtils.startsWithAny(nom, "zcobol_")),
    ZCOPY(
            "Zcopy_",
            nom -> StringUtils.startsWithAny(nom, "zcopy_")),
    ZBMS(
            "Zbms_",
            nom -> StringUtils.startsWithAny(nom, "zbms_")),
    CHART_HELM(
            "Chart Helm",
            nom -> StringUtils.startsWithAny(nom, "helm_")),
    PUBLICATION_ANSIBLE(
            "Publication Ansible",
            nom -> StringUtils.startsWithAny(nom, "publication_ansible_vars")),

    INFRASTRUCTURE_AS_CODE_CLOUD_NATIF(
            "IaC Cloud natif",
            nom -> (StringUtils.startsWithAny(nom, "deploiement_helm", "deploiement_k8s") ||
                    StringUtils.startsWithAndEndsWith(nom, "deploiement", "k8s") ||
                    StringUtils.containsAndEndsWith(nom, "hexaboot", "_cd"))),

    INCONNU("Inconnu", nom -> (true));

    private final Predicate<String> predicate;
    private final String libelle;

    TypeDeComposant(String libelle, Predicate<String> predicate) {
        this.libelle = libelle;
        this.predicate = predicate;
    }

    public String getLibelle() {
        return libelle;
    }

    public static TypeDeComposant find(String nomComposant) {
        if (nomComposant == null) {
            return INCONNU;
        }
        return Arrays.asList(TypeDeComposant.values()).stream().filter(
                type -> type.predicate.test(nomComposant))
                .findFirst().orElse(null);
    }

}