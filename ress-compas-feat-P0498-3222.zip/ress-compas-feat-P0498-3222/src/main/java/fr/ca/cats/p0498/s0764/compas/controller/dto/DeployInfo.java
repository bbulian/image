package fr.ca.cats.p0498.s0764.compas.controller.dto;

import java.time.OffsetDateTime;

public record DeployInfo(
        String commit,
        String ref,
        OffsetDateTime deploy,
        OffsetDateTime lastScan) { }
