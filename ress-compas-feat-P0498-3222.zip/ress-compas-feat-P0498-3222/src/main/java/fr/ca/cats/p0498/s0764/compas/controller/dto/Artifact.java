package fr.ca.cats.p0498.s0764.compas.controller.dto;

import fr.ca.cats.p0498.s0764.compas.domain.models.TypeDeComposant;

public record Artifact(
		String type,
		String name,
		String version,
		String checksum,
		Component composantLink,
		Repository repository,
		BuildInfo buildInfo,
		Image image
) {
	public Artifact(fr.ca.cats.p0498.s0764.compas.repositories.domain.view.Artifact data) {
		this(
				data.getDependanceType(),
				data.getDependanceName(),
				data.getDependanceVersion(),
				data.getDependanceChecksum(),
				new Component(
						TypeDeComposant.find(data.getComposantName()).getLibelle(),
						data.getComposantName(),
						new Manifest(
								data.getComposantCodeProduit(),
								data.getComposantCodeSolution()
						)
				),
				new Repository(data.getComposantRepoUrl()),
				new BuildInfo(
						data.getComposantRepoCommit(),
						data.getComposantRepoRef(),
						data.getComposantRepoTag()
				),
				new Image(
						data.getImageName(),
						data.getImageVersion(),
						data.getImageChecksum(),
						new ImageManifest(
								data.getImageProduit(),
								data.getImageSolution(),
								new ImageRepo(
										data.getImageRepoUrl(),
										data.getImageRepoCommit(),
										data.getImageRepoRef(),
										data.getImageRepoTag()
								)
						)
				)
		);
	}
}
