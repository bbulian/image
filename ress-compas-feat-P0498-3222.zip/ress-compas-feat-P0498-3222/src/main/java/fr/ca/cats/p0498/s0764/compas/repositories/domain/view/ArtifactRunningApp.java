package fr.ca.cats.p0498.s0764.compas.repositories.domain.view;

import fr.ca.cats.p0498.s0764.compas.repositories.domain.RunningApp;
import fr.ca.cats.p0498.s0764.compas.repositories.domain.RunningArtifact;

public record ArtifactRunningApp(RunningApp runningApp, RunningArtifact runningArtifact) { }
