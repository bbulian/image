package fr.ca.cats.p0498.s0764.compas.repositories.domain;

import java.util.UUID;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Entity
@Table(name = "RUNNING_ARTIFACT")
@Getter
@Setter
@Accessors(chain = true)
public class RunningArtifact {

	@Id
	@Column(nullable = false, updatable = false, columnDefinition = "VARCHAR(36)")
	@JdbcTypeCode(SqlTypes.VARCHAR)
	@GeneratedValue(strategy = GenerationType.UUID)
	private UUID id;

	@Column(name = "NAME")
	private String name;

	@Column(name = "VERSION")
	private String version;

	@Column(name = "TYPE")
	private String type = "docker";

	@Column(name = "CHECKSUM_VALUE")
	private String checksumValue;

	@Column(name = "CHECKSUM_ALG")
	private String checksumAlg;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "FK_RUNNING_APP_ID", nullable = false)
	private RunningApp runningApp;

}
