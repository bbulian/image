package fr.ca.cats.p0498.s0764.compas.repositories.domain;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Entity
@Table(name = "COMPONENT")
@Getter
@Setter
@Accessors(chain = true)
public class Component {

	@Id
	@Column(nullable = false, updatable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "NAME")
	private String name;

	@Column(name = "CODE_EDS", length = 5)
	private String codeEds;

	@Column(name = "CODE_PRODUIT", length = 5)
	private String codeProduit;

	@Column(name = "CODE_SOLUTION", length = 5)
	private String codeSolution;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "CREATED_AT")
	private LocalDateTime createdAt = LocalDateTime.now();

	@OneToOne(cascade = CascadeType.ALL, optional = false)
	@JoinColumn(name = "FK_REPOSITORY_ID", referencedColumnName = "ID")
	private Repository repository;

	@JsonIgnore
	@OneToMany(mappedBy = "component")
	private Set<BuildInfo> buildInfos = new HashSet<>();

}
