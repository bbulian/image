package fr.ca.cats.p0498.s0764.compas.controller.dto;

import java.io.Serializable;

public record ImageManifest(String imageProduit, String imageSolution, ImageRepo imageRepo) { }
