package fr.ca.cats.p0498.s0764.compas.controller;

import fr.ca.cats.p0498.s0764.compas.exception.ApiErrorResponse;
import fr.ca.cats.p0498.s0764.compas.exception.CompasException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

/**
 * This controller is call when an error.
 * You can catch know error or another error.
 *
 * If an error occur in this controller, CompasErrorController class catch this.
 */
@RestControllerAdvice
public class ControllerExceptionHandler {
    /**
     * Logger.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ControllerExceptionHandler.class);

    /**
     * Business class exception.
     *
     * @return error
     */
    @ExceptionHandler({CompasException.class})
    public ResponseEntity<ApiErrorResponse> artefactNotFoundException(CompasException ex) {
        return ResponseEntity
                .status(ex.getHttpCode())
                .contentType(MediaType.APPLICATION_JSON)
                .body(
                        new ApiErrorResponse(ex.getHttpCode(), ex.getMessage())
                );
    }

    /**
     * Catch Spring framework error expected.
     *
     * @return error
     */
    @ExceptionHandler({NoHandlerFoundException.class, NoResourceFoundException.class})
    public ResponseEntity<ApiErrorResponse> handleNoHandlerFoundException() {
        return ResponseEntity
                .status(CompasException.NOT_FOUND)
                .contentType(MediaType.APPLICATION_JSON)
                .body(
                        new ApiErrorResponse(
                                CompasException.NOT_FOUND,
                                "Le chemin demandé est introuvable. Est-vous certain de l'url ?"));
    }

    /**
     * If unknown error raise, we log it.
     *
     * @param ex exception
     *
     * @return response
     */
    @ExceptionHandler({Exception.class})
    public ResponseEntity<ApiErrorResponse> exception(Exception ex) {
        LOGGER.error("Erreur imprévue", ex);
        return ResponseEntity
                .status(CompasException.INTERNAL_SERVER_ERROR)
                .contentType(MediaType.APPLICATION_JSON)
                .body(
                        new ApiErrorResponse(
                                CompasException.INTERNAL_SERVER_ERROR,
                                "Une erreur imprévue est survenue au niveau du serveur. " +
                                        "Veuillez nous excuser pour la gêne occasionée")
                );
    }
}
