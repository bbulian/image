package fr.ca.cats.p0498.s0764.compas.repositories.domain;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Entity
@Table(name = "ARTIFACT")
@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
public class Artifact {

	@Id
	@Column(nullable = false, updatable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "CHECKSUM_VALUE", nullable = false)
	private String checksumValue;

	@Column(name = "CHECKSUM_ALG", nullable = false)
	private String checksumAlg;

	@Column(name = "NAME", nullable = false)
	private String name;

	@Column(name = "VERSION", nullable = false)
	private String version;

	@Column(name = "TYPE", nullable = false)
	private String type;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "CREATED_AT")
	private LocalDateTime createdAt = LocalDateTime.now();

	@OneToMany(mappedBy = "artifact")
	private Set<Dependency> dependencies = new HashSet<>();

	@ToString.Exclude
	@JsonIgnore
	@ManyToMany(mappedBy = "artifacts", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private Set<BuildInfo> buildInfos = new HashSet<>();

}
