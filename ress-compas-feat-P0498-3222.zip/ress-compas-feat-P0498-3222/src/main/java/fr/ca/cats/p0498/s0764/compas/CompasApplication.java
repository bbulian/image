package fr.ca.cats.p0498.s0764.compas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories(basePackages = "fr.ca.cats.p0498.s0764.compas.repositories")
@SpringBootApplication
public class CompasApplication {
    public static void main(String[] args) {
        SpringApplication.run(CompasApplication.class, args);
    }
}
