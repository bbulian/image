package fr.ca.cats.p0498.s0764.compas.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.ca.cats.p0498.s0764.compas.repositories.domain.Component;


public interface ComponentRepository extends JpaRepository<Component, Integer> {

}
