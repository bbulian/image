package fr.ca.cats.p0498.s0764.compas.controller;

import fr.ca.cats.p0498.s0764.compas.exception.ApiErrorResponse;
import fr.ca.cats.p0498.s0764.compas.exception.CompasException;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * This controller is call when an error occur somewhere, including in ControllerExceptionHandler class file.
 */
@RestController
@Tag(name = "ERROR HANDLER")
@RequiredArgsConstructor
public class CompasErrorController implements ErrorController {
    @RequestMapping(value = "/error")
    @ResponseBody
    public ResponseEntity<ApiErrorResponse> getErrorPath() {
        return ResponseEntity
                .status(CompasException.NOT_FOUND)
                .contentType(MediaType.APPLICATION_JSON)
                .body(
                        new ApiErrorResponse(
                                CompasException.NOT_FOUND,
                                "Le chemin demandé n'existe pas."));
    }
}
