package fr.ca.cats.p0498.s0764.compas.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.ca.cats.p0498.s0764.compas.repositories.domain.Repository;


public interface RepositoryRepository extends JpaRepository<Repository, Integer> {

}
