package fr.ca.cats.p0498.s0764.compas.repositories.domain;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Entity
@Table(name = "BUILD_INFO")
@Getter
@Setter
@Accessors(chain = true)
public class BuildInfo {

	@Id
	@Column(nullable = false, updatable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "COMMIT", length = 50)
	private String commit;

	@Column(name = "BRANCH", length = 50)
	private String branch;

	@Column(name = "TAG", length = 50)
	private String tag;

	@Column(name = "PIPELINE_URL")
	private String pipelineUrl;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(nullable = false, name = "CREATED_AT")
	private LocalDateTime createdAt = LocalDateTime.now();

	@ManyToOne
	@JoinColumn(name = "FK_COMPONENT_ID", nullable = false)
	private Component component;

	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "LINK_BUILD", joinColumns = @JoinColumn(name = "FK_BUILD_INFO_ID"), inverseJoinColumns = @JoinColumn(name = "FK_ARTIFACT_ID"))
	private Set<Artifact> artifacts = new HashSet<>();

}
