package fr.ca.cats.p0498.s0764.compas.repositories;


import java.util.List;
import java.util.UUID;

import fr.ca.cats.p0498.s0764.compas.repositories.domain.view.ArtifactRunningApp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import fr.ca.cats.p0498.s0764.compas.controller.dto.Environnement;
import fr.ca.cats.p0498.s0764.compas.repositories.domain.view.ProduitSolution;
import fr.ca.cats.p0498.s0764.compas.repositories.domain.RunningApp;

public interface RunningAppRepository extends JpaRepository<RunningApp, UUID> {

	@Query("""
			SELECT DISTINCT new fr.ca.cats.p0498.s0764.compas.controller.dto.Environnement(app.env, count(*))
			FROM RunningApp app
			WHERE app.env in :listEnv
			GROUP BY app.env
			""")
	List<Environnement> getRunningAppCountByEnv(@Param("listEnv") List<String> listEnv);

	@Query("""
			SELECT DISTINCT new fr.ca.cats.p0498.s0764.compas.repositories.domain.view.ProduitSolution(app.codeProduit, app.codeSolution)
			FROM RunningApp app
			WHERE app.env = :env AND
			      app.installedFrom = :env_type
			""")
	List<ProduitSolution> getProduitSolutionByEnvAndEnvType(@Param("env") String env, @Param("env_type") RunningApp.InstalledFrom env_type);

	// On utilise "(:env_type is null OR app.installedFrom = :env_type)" afin de permettre d'avoir le type optionnel.
	@Query("""
			SELECT app
			FROM RunningApp app
			WHERE app.env = :env AND
			      app.codeProduit = :produit AND
			      app.codeSolution = :solution AND
				  (:env_type is null OR app.installedFrom = :env_type)
			""")
	List<RunningApp> getRunningApps(@Param("env") String env, @Param("env_type") RunningApp.InstalledFrom env_type, @Param("produit") String produit, @Param("solution") String solution);

	// On utilise "(:env_type is null OR app.installedFrom = :env_type)" afin de permettre d'avoir le type optionnel.
	@Query("""
			SELECT DISTINCT new fr.ca.cats.p0498.s0764.compas.repositories.domain.view.ArtifactRunningApp(app, artifact)
			FROM RunningApp app
			INNER JOIN RunningArtifact artifact
				  ON app.id = artifact.runningApp.id
			WHERE app.env = :env AND
			      app.installedFrom = :env_type AND
				  (:env_type is null OR app.installedFrom = :env_type)
			""")
	List<ArtifactRunningApp> getRunningAppsByEnvAndEnvType(@Param("env") String env, @Param("env_type") RunningApp.InstalledFrom env_type);
}
