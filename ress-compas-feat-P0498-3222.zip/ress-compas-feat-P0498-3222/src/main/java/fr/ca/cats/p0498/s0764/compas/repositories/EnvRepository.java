package fr.ca.cats.p0498.s0764.compas.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.ca.cats.p0498.s0764.compas.repositories.domain.Env;
import org.springframework.data.jpa.repository.Query;

public interface EnvRepository extends JpaRepository<Env, String> {

	@Query("""
			SELECT env 
			FROM Env env 
			WHERE env.afficher = true
			""")
	List<Env> getEnvToDisplay();

}
