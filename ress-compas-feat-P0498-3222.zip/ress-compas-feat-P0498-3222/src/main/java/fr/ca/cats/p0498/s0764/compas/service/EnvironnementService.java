package fr.ca.cats.p0498.s0764.compas.service;

import fr.ca.cats.p0498.s0764.compas.controller.dto.DeploiementsProduitSolutionEnvironnement;
import fr.ca.cats.p0498.s0764.compas.controller.dto.Deployment;
import fr.ca.cats.p0498.s0764.compas.controller.dto.Environnement;
import fr.ca.cats.p0498.s0764.compas.controller.dto.Image;
import fr.ca.cats.p0498.s0764.compas.repositories.EnvRepository;
import fr.ca.cats.p0498.s0764.compas.repositories.RunningAppRepository;
import fr.ca.cats.p0498.s0764.compas.repositories.domain.Env;
import fr.ca.cats.p0498.s0764.compas.repositories.domain.view.ArtifactRunningApp;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ca.cats.p0498.s0764.compas.repositories.domain.RunningApp.InstalledFrom;

@Service
@RequiredArgsConstructor
public class EnvironnementService {
    /**
     * Base de données ENV.
     */
    private final EnvRepository envRepository;

    /**
     * Running application.
     */
    private final RunningAppRepository runningAppRepo;

    /**
     * Logger.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(EnvironnementService.class);
    private final RunningAppRepository runningAppRepository;

    /**
     * Get list of Kubernetes environments.
     *
     * @return list of environment with number of current applications running.
     */
    public List<Environnement> getKubernetesEnvironnements() {
        LOGGER.debug("Get list of environment");

        var listEnv = envRepository
                .getEnvToDisplay()
                .stream()
                .map(Env::getName)
                .toList();
        return runningAppRepo.getRunningAppCountByEnv(listEnv);
    }

    /**
     * Return list of applications for a list of tuple Produit/Solution.
     *
     * @param env               environment to get
     * @param type              filter type of applications
     *
     * @return list of application.
     */
    public List<DeploiementsProduitSolutionEnvironnement> getDeploymentsByEnvType(String env, InstalledFrom type) {
        LOGGER.debug("Get all deployments for env = '{}' and type = '{}'", env, type);

        Map<AbstractMap.SimpleImmutableEntry<String, String>, List<ArtifactRunningApp>> runningApps = runningAppRepository.getRunningAppsByEnvAndEnvType(
                env,
                type)
                .stream()
                .collect(
                        Collectors.groupingBy(
                                o -> new AbstractMap.SimpleImmutableEntry<>(o.runningApp().getCodeProduit(), o.runningApp().getCodeSolution())
                                )
                        );

        List<DeploiementsProduitSolutionEnvironnement> deployementsList = new ArrayList<>(runningApps.size());

        runningApps.forEach(
                (key, runningAppsList) -> {
                    List<Deployment> deployments = convertRunningAppsToDeployment(runningAppsList);

                    DeploiementsProduitSolutionEnvironnement deployment = new DeploiementsProduitSolutionEnvironnement(
                            key.getKey(),
                            key.getValue(),
                            deployments
                    );

                    deployementsList.add(deployment);
                });

        LOGGER.debug("End of all deployments for env = '{}' and type = '{}'", env, type);

        return deployementsList;
    }

    /**
     * Get list of deployment of one running application.
     *
     * @param runningApps list of running app.
     * @return list of deployment.
     */
    private List<Deployment> convertRunningAppsToDeployment(List<ArtifactRunningApp> runningApps) {
        Map<UUID, Deployment> deployments = new HashMap<>();

        for (ArtifactRunningApp app : runningApps) {
        var id = app.runningApp().getId();
        Deployment deployment = deployments.get(id);

        if (deployment == null) {
            deployment = new Deployment(app.runningApp());
            deployments.put(id, deployment);
        }
        deployment.images().add(new Image(app.runningArtifact()));
    }
        return new ArrayList<>(deployments.values());
    }

}
