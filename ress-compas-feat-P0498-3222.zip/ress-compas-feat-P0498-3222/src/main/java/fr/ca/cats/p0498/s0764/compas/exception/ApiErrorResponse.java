package fr.ca.cats.p0498.s0764.compas.exception;

public record ApiErrorResponse(int code, String message) {
}
