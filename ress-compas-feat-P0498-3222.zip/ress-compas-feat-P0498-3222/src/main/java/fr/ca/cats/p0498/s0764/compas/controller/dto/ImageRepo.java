package fr.ca.cats.p0498.s0764.compas.controller.dto;

import fr.ca.cats.p0498.s0764.compas.repositories.domain.RunningArtifact;

public record ImageRepo(
        String imageRepoUrl,
        String imageRepoCommit,
        String imageRepoRef,
        String imageRepoTag) { }
