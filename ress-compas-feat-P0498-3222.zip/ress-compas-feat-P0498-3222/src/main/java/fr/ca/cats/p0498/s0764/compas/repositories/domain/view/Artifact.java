package fr.ca.cats.p0498.s0764.compas.repositories.domain.view;

public interface Artifact {
	String getDependanceChecksum();
	String getDependanceName();
	String getDependanceVersion();
	String getDependanceType();
	String getComposantCodeProduit();
	String getComposantCodeSolution();
	String getComposantRepoUrl();
	String getComposantRepoCommit();
	String getComposantRepoRef();
	String getComposantRepoTag();
	String getComposantName();
	String getImageName();
	String getImageVersion();
	String getImageChecksum();
	String getImageProduit();
	String getImageSolution();
	String getImageRepoUrl();
	String getImageRepoCommit();
	String getImageRepoRef();
	String getImageRepoTag();
}
