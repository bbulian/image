package fr.ca.cats.p0498.s0764.compas.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class CompasException extends Exception {
    /**
     * HTTP code.
     */
    private final int httpCode;

    /**
     * Message return in JSON body response.
     */
    private final String message;

    /**
     * Resource not found.
     */
    public static int NOT_FOUND = 404;

    /**
     * Internal server error :(
     */
    public static int INTERNAL_SERVER_ERROR = 500;

    /**
     * Create error artifact not found exception.
     *
     * @return CompasException an error
     */
    public static CompasException artifactNotFound() throws CompasException {
        return  new CompasException(NOT_FOUND, "L'artefact demandé est introuvable");
    }

    /**
     * Database error.
     *
     * @param message The message or context to be more clear.
     *
     * @return Database error
     */
    public static CompasException databaseServerError(String message) throws CompasException {
        return new CompasException(
                INTERNAL_SERVER_ERROR,
                String.format("Une erreur est survenue au niveau de la connexion entre le serveur " +
                        "et la la base de données. Contexte : %s", message)
                );
    }
}
