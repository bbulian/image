package fr.ca.cats.p0498.s0764.compas.repositories.domain;

import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Entity
@Table(name = "ENV")
@Getter
@Setter
@Accessors(chain = true)
public class Env {

	@Id
	@Column(name = "NAME", nullable = false, updatable = false)
	private String name;

	@Column(name = "AFFICHER")
	private boolean afficher;

	@Column(name = "CREATED_AT")
	private OffsetDateTime createdAt = OffsetDateTime.now();

}
