package fr.ca.cats.p0498.s0764.compas.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

import fr.ca.cats.p0070.s1889.authentication.web.security.CustomSecurityConfigurer;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(
        securedEnabled = true,
        jsr250Enabled = true)
public class WebSecurityConfig {
    private static final String[] AUTH_WHITELIST = {
            "/error",
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/actuator/**",
            "/environnement/**",
            "/artefact/**",
    };

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, CustomSecurityConfigurer customSecurityConfigurer) throws Exception {
        http
                .sessionManagement(sess -> sess.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(authz -> authz
                        .requestMatchers(AUTH_WHITELIST).permitAll()
                        .anyRequest().authenticated()
                )
                .csrf(AbstractHttpConfigurer::disable)
                .with(customSecurityConfigurer, Customizer.withDefaults());
        return http.build();
    }

    /**
     * The purpose of this method is to exclude the URLs' specific to Login, Swagger UI and static files.
     * Any URL that should be excluded from the Spring security chain should be added to the ignored list in this
     * method only
     */
    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return web -> web.ignoring().requestMatchers(AUTH_WHITELIST);
    }
}
