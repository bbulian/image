package fr.ca.cats.p0498.s0764.compas.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import fr.ca.cats.p0498.s0764.compas.repositories.domain.Artifact;

public interface ArtifactRepository extends JpaRepository<Artifact, Integer> {
	
	@Query(nativeQuery = true, value = 
			"""
				SELECT DISTINCT
				    enfant.CHECKSUM_VALUE as 'dependanceChecksum',
				    enfant.NAME as 'dependanceName',
				    enfant.VERSION as 'dependanceVersion',
				    enfant.type as 'dependanceType',
				    c.CODE_PRODUIT as 'composantCodeProduit',
				    c.CODE_SOLUTION as 'composantCodeSolution',
				    c.NAME as 'composantName',
				    repo.URL as 'composantRepoUrl',
				    bi.commit as 'composantRepoCommit',
				    bi.BRANCH as 'composantRepoRef',
				    bi.tag as 'composantRepoTag'
				FROM
				    ARTIFACT parent
				    INNER JOIN ARTIFACT_DEPENDENCY ad ON  (ad.FK_ARTIFACT_ID = parent.ID)
				    INNER JOIN ARTIFACT enfant ON (enfant.CHECKSUM_VALUE = ad.DEPENDENCY_CHECKSUM_VALUE and enfant.CHECKSUM_ALG = ad.DEPENDENCY_CHECKSUM_ALG)
				    LEFT JOIN LINK_BUILD lb ON lb.FK_ARTIFACT_ID = enfant.ID
				    LEFT JOIN BUILD_INFO bi ON bi.ID = lb.FK_BUILD_INFO_ID
				    LEFT JOIN COMPONENT c ON c.ID = bi.FK_COMPONENT_ID
				    LEFT JOIN REPOSITORY repo ON c.FK_REPOSITORY_ID = repo.ID
				WHERE
				    parent.CHECKSUM_VALUE = :checksumArtefact
				""")
	List<fr.ca.cats.p0498.s0764.compas.repositories.domain.view.Artifact> getArtifactDependenciesByChecksum(@Param("checksumArtefact") String checksumArtefact);

	@Query(nativeQuery = true, value =
	"""
		SELECT DISTINCT
			NAME as composantName,
			TYPE as composantType
		FROM
			ARTIFACT
		WHERE
			CHECKSUM_VALUE = :checksumArtefact
		""")
	fr.ca.cats.p0498.s0764.compas.repositories.domain.view.Artifact getArtifactByChecksum(@Param("checksumArtefact") String checksumArtefact);
}
