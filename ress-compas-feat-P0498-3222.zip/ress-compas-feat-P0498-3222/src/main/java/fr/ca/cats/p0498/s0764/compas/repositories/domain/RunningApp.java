package fr.ca.cats.p0498.s0764.compas.repositories.domain;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Entity
@Table(name = "RUNNING_APP")
@Getter
@Setter
@Accessors(chain = true)
public class RunningApp {

	public enum InstalledFrom {
		K8S,
		ANS,
		DKR
	}

	@Id
	@Column(nullable = false, updatable = false, columnDefinition = "VARCHAR(36)")
	@JdbcTypeCode(SqlTypes.VARCHAR)
	@GeneratedValue(strategy = GenerationType.UUID)
	private UUID id;

	@Column(name = "APP_NAMESPACE")
	private String appNamespace;

	@Column(name = "APP_NAME")
	private String appName;

	@Column(name = "ENV")
	private String env;
	
	@Column(name = "APP_URL")
	private String appUrl;

	@Column(name = "APP_STATUS")
	private String appStatus;

	@Column(name = "REPO_URL")
	private String repoUrl;

	@Column(name = "REPO_REF")
	private String repoRef;
	
	@Column(name = "REPO_COMMIT")
	private String repoCommit;

	@Column(name = "SERVER")
	private String server;

	@Column(name = "CODE_PRODUIT", length = 5)
	private String codeProduit;

	@Column(name = "CODE_SOLUTION", length = 5)
	private String codeSolution;

	@Column(name = "CREATED_AT")
	private OffsetDateTime createdAt = OffsetDateTime.now();

	@Column(name = "DEPLOYED_AT")
	private OffsetDateTime deployedAt = OffsetDateTime.now();
	
	@Enumerated(EnumType.STRING)
	@Column(name = "INSTALLED_FROM", columnDefinition = "VARCHAR(50)")
	private InstalledFrom installedFrom;

	@OneToMany(mappedBy = "runningApp", fetch = FetchType.EAGER)
	private List<RunningArtifact> runningArtifacts = new ArrayList<>();

	public void addRunniArtifact(RunningArtifact ra) {
		runningArtifacts.add(ra);
		// ra.setRunningApp(this);
	}

	public void addAll(Set<RunningArtifact> ra) {
		for (RunningArtifact runningArtifact : ra) {
			this.addRunniArtifact(runningArtifact);
		}
	}

}
