package fr.ca.cats.p0498.s0764.compas.controller.dto;

import java.util.List;

public record DeploiementsProduitSolutionEnvironnement(Manifest manifest, List<Deployment> deployments) {
	public DeploiementsProduitSolutionEnvironnement(String produit, String solution, List<Deployment> deploy) {
		this(
				new Manifest(produit, solution),
				deploy
		);
	}
}
