package fr.ca.cats.p0498.s0764.compas.utils;

public class StringUtils {
	
	private StringUtils() {}

	/**
	 * Commencer par "..."
	 *
	 * @param nomComposant nom du composant en minuscules
	 * @param prefixes obligatoires et en minuscules
	 *
	 * @return true/false
	 */
	public static boolean startsWithAny(String nomComposant, String... prefixes) {
		for (String prefix : prefixes) {
			if (nomComposant.toLowerCase().startsWith(prefix)) {
				return true;
			}
		}
		return false;
	}

	
	/**
	 * Termine par
	 *
	 * @param nomComposant nom du composant en minuscules
	 * @param suffixes obligatoires et en minuscules
	 *
	 * @return true/false
	 */
	public static boolean endsWithAny(String nomComposant, String... suffixes) {
		for (String suffixe : suffixes) {
			if (nomComposant.toLowerCase().endsWith(suffixe)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Commencer par x et fini par y
	 *
	 * @param nomComposant nom du composant en minuscules
	 * @param prefixe en minuscule
	 * @param suffixe en minuscule
	 *
	 * @return true/false
	 */
	public static boolean startsWithAndEndsWith(String nomComposant, String prefixe, String suffixe) {
		return nomComposant.toLowerCase().startsWith(prefixe) && nomComposant.toLowerCase().endsWith(suffixe);
	}

	/**
	 * Contient x et fini par y
	 *
	 * @param nomComposant nom du composant en minuscules
	 * @param contains en minuscule
	 * @param suffixe en minuscule
	 *
	 * @return true/false
	 */
	public static boolean containsAndEndsWith(String nomComposant, String contains, String suffixe) {
		return nomComposant.toLowerCase().contains(contains) && nomComposant.toLowerCase().endsWith(suffixe);
	}

	/**
	 * Commencer par "..." et contient un de "..."
	 *
	 * @param nomComposant nom du composant en minuscules
	 * @param startWith en minuscule
	 * @param contains en minuscule
	 *
	 * @return true/false
	 */
	public static boolean startsWithAndContainsAny(String nomComposant, String startWith, String... contains) {
		if (nomComposant.toLowerCase().startsWith(startWith)) {
			for (String contain : contains) {
				if (nomComposant.toLowerCase().contains(contain)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Commencer par "..." OU contient un de "..."
	 *
	 * @param nomComposant nom du composant en minuscules
	 * @param startWith en minuscule
	 * @param contains en minuscule
	 *
	 * @return true/false
	 */
	public static boolean startsWithOrContainsAny(String nomComposant, String startWith, String... contains) {
		if (nomComposant.toLowerCase().startsWith(startWith)) {
			return true;
		}
		for (String contain : contains) {
			if (nomComposant.toLowerCase().contains(contain)) {
				return true;
			}
		}
		return false;
	}
}
