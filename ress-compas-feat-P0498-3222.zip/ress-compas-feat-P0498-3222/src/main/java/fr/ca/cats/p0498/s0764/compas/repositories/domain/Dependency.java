package fr.ca.cats.p0498.s0764.compas.repositories.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Entity
@Table(name = "ARTIFACT_DEPENDENCY")
@Getter
@Setter
@Accessors(chain = true)
public class Dependency {

	@Id
	@Column(nullable = false, updatable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "DEPENDENCY_CHECKSUM_VALUE", nullable = false)
	private String dependencyChecksumValue;

	@Column(name = "DEPENDENCY_CHECKSUM_ALG", nullable = false)
	private String dependencyChecksumAlg;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "FK_ARTIFACT_ID", nullable = false)
	private Artifact artifact;
}
