package fr.ca.cats.p0498.s0764.compas.controller.dto;

import fr.ca.cats.p0498.s0764.compas.repositories.domain.RunningArtifact;

import java.util.ArrayList;

public record Image(
        String imageName,
        String imageVersion,
        String imageChecksum,
        ImageManifest imageManifest) {

    public Image(RunningArtifact runningArtifact) {
        this(
            runningArtifact.getName(),
            runningArtifact.getVersion(),
            runningArtifact.getChecksumValue(),
            new ImageManifest(
                    runningArtifact.getRunningApp().getCodeProduit(),
                    runningArtifact.getRunningApp().getCodeSolution(),
                    new ImageRepo(
                            runningArtifact.getRunningApp().getRepoCommit(),
                            runningArtifact.getRunningApp().getRepoUrl(),
                            runningArtifact.getRunningApp().getRepoRef(),
                            runningArtifact.getRunningApp().getRepoRef()
                    )
            )
        );
    }
}
