package fr.ca.cats.p0498.s0764.compas.repositories.domain.view;

import lombok.Data;

import java.io.Serializable;

@Data
public class ProduitSolution implements Serializable {
	private String codeProduit;

	private String codeSolution;

	public ProduitSolution(String produit, String solution) {
		codeProduit = produit;
		codeSolution = solution;
	}
}
