package fr.ca.cats.p0498.s0764.compas.service;

import java.util.List;

import fr.ca.cats.p0498.s0764.compas.exception.CompasException;
import static fr.ca.cats.p0498.s0764.compas.exception.CompasException.databaseServerError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import fr.ca.cats.p0498.s0764.compas.controller.dto.Artifact;
import lombok.RequiredArgsConstructor;

/**
 * Class to connect to database and manage artifact.
 */
@Service
@RequiredArgsConstructor
public class ArtifactDependenciesService {
	/**
	 * Artifact database.
	 */
	private final fr.ca.cats.p0498.s0764.compas.repositories.ArtifactRepository artifactRepository;

	/**
	 * Logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ArtifactDependenciesService.class);

	/**
	 * Return list of dependencies of an artifact.
	 *
	 * @param checksumArtifact artifact checksum
	 *
	 * @return list of dependencies
	 *
	 * @throws CompasException if any error with database
	 */
	public List<Artifact> getArtifactDependencies(String checksumArtifact) throws CompasException {
		try {
			return artifactRepository
					.getArtifactDependenciesByChecksum(checksumArtifact)
					.stream()
					.map(Artifact::new)
					.toList();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw databaseServerError("récupération des artefacts de dépendances");
		}
	}

	/**
	 * Return one artifact.
	 *
	 * @param checksumArtifact artifact checksum
	 *
	 * @return return one artifact
	 *
	 * @throws CompasException if any error with database
	 */
	public Artifact getArtifact(String checksumArtifact) throws CompasException {
		try {
			return new Artifact(
					artifactRepository.getArtifactByChecksum(checksumArtifact));
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw databaseServerError("récupération d'un artefact");
		}
	}
}
