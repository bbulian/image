package fr.ca.cats.p0498.s0764.compas.controller.dto;

import fr.ca.cats.p0498.s0764.compas.repositories.domain.RunningApp;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public record Deployment(
        Dashboard dashboard,
        DeployInfo deployInfo,
        Repository repository,
        List<Image> images
) {
    public Deployment(RunningApp app) {
        this(
            new Dashboard(app.getAppUrl()),
            new DeployInfo(
                app.getRepoCommit(),
                app.getRepoRef(),
                app.getDeployedAt(),
                app.getCreatedAt()),
            new Repository(app.getRepoUrl()),
            new ArrayList<>());
    }
}
